Q1: I used SSL encryption for (4) -> (5). and (5)->(6).
Q2: To ensure the price was exactly same as the Buy_Price, a session with Buy_Price
was created and stored on the server Side when the item page is generated. The browser retrieve the cookie and the session ID was stored in the cookie for the further retrieval of the Buy_Price in the session

