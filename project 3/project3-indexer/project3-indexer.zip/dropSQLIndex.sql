DROP INDEX ItemSpIndex ON Locations;
DROP TABLE IF EXISTS Locations;
