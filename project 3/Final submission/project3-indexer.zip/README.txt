I would like to use one day grace period
The index will be built in the directory of "/var/lib/lucene/"
Before building the index, the directory and all the files in "/var/lib/lucene/" will be deleted
