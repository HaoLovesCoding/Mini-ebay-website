####First Question

Item(ItemID,Item Name,Current Price, Buy Price, First Bid,Number Of Bid,Item Location, Location Latitude, Location Longitude, Country, Started Time, End Time, SellerID, Description)
Key:ItemID

Category (ItemID, Category)
Keys:ItemID,Category

User(UserID, SellerRating, BidderRating, Country, Location)
Key:UserID

Bid (ItemID,Time,UserID, Amount)
Keys:ItemID,Time,UserID

####Second Question

No nontrivial functional dependencies except the keys hold

####Third Question

Yes

####Forth Question

Yes
